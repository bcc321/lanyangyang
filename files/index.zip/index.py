'use strict';
/**
 * CloudShare 账号云函数（腾讯云 SCF / 函数 URL）
 * 零依赖：只用 Node.js 内置 tls / https / crypto，无需 npm install、无需上传 zip。
 *
 * 接口（App 端 CloudApi.kt 已按此实现）：
 *   POST {action:"sendCode",      qqNumber}                 -> 发 6 位验证码到 QQ 邮箱
 *   POST {action:"verifyCode",    qqNumber, code, password} -> 账号存在=登录，不存在=注册
 *   POST {action:"resetPassword", qqNumber, code, password} -> 验证码通过后改密码
 * 返回：{ success:true|false, message:"给用户看的中文提示", isNew?:true }
 *
 * 环境变量（云函数控制台 -> 函数配置 -> 环境变量）：
 *   QQ_USER    发信 QQ 邮箱，如 2147706417@qq.com
 *   QQ_PASS    QQ 邮箱 SMTP 授权码（不是登录密码！QQ邮箱设置->账户->开启SMTP拿16位码）
 *   GH_TOKEN   GitHub 个人访问令牌（repo 权限；用于保存账号表）
 *   GH_REPO    仓库全名，如 yourname/cloudshare
 *   GH_BRANCH  分支，默认 main
 *   GH_PATH    账号文件名，默认 accounts.json（不存在会自动创建）
 */

const tls = require('tls');
const https = require('https');
const crypto = require('crypto');

const CFG = {
  qqUser: process.env.QQ_USER || '',
  qqPass: process.env.QQ_PASS || '',
  ghToken: process.env.GH_TOKEN || '',
  ghRepo: process.env.GH_REPO || '',
  ghBranch: process.env.GH_BRANCH || 'main',
  ghPath: process.env.GH_PATH || 'accounts.json',
  smtpHost: process.env.SMTP_HOST || 'smtp.qq.com',
  smtpPort: parseInt(process.env.SMTP_PORT || '465', 10),
};

/* ------------------------------------------------------------------ */
/* 1. 极简 SMTP 客户端（TLS 465，AUTH LOGIN）                          */
/* ------------------------------------------------------------------ */

function makeReader(sock) {
  let buf = '';
  const queue = [];
  let waiting = null;
  sock.on('data', (d) => {
    buf += d.toString('utf8');
    let i;
    while ((i = buf.indexOf('\r\n')) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 2);
      const m = line.match(/^(\d{3}) /);
      if (m) {
        const resp = { code: parseInt(m[1], 10), line };
        if (waiting) { const w = waiting; waiting = null; w(resp); }
        else queue.push(resp);
      }
    }
  });
  return () => (queue.length ? Promise.resolve(queue.shift())
    : new Promise((r) => { waiting = r; }));
}

function b64(s) { return Buffer.from(s, 'utf8').toString('base64'); }
function wrap76(s) { return (s.match(/.{1,76}/g) || []).join('\r\n'); }

function buildMime(from, to, subject, text) {
  const head = [
    'From: "CloudShare" <' + from + '>',
    'To: <' + to + '>',
    'Subject: =?UTF-8?B?' + b64(subject) + '?=',
    'Date: ' + new Date().toUTCString(),
    'Message-ID: <' + crypto.randomBytes(8).toString('hex') + '@cloudshare>',
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
  ].join('\r\n');
  return head + '\r\n\r\n' + wrap76(b64(text));
}

function sendMail(to, subject, text) {
  return new Promise((resolve, reject) => {
    const sock = tls.connect({ host: CFG.smtpHost, port: CFG.smtpPort, servername: CFG.smtpHost });
    let finished = false;
    let timer = null;
    const done = (err) => {
      if (finished) return;
      finished = true;
      if (timer) clearTimeout(timer);
      try { sock.destroy(); } catch (e) { /* ignore */ }
      if (err) reject(err); else resolve(true);
    };
    timer = setTimeout(() => done(new Error('SMTP 超时（网络或端口被限制）')), 20000);
    sock.once('error', (e) => done(e));
    sock.once('secureConnect', async () => {
      const next = makeReader(sock);
      const cmd = async (line, want) => {
        sock.write(line + '\r\n');
        const r = await next();
        if (!r) throw new Error('SMTP 连接中断');
        if (want && r.code !== want) throw new Error('SMTP 阶段失败(' + r.code + ')：' + r.line);
        return r;
      };
      try {
        if ((await next()).code !== 220) throw new Error('SMTP 未就绪');
        await cmd('EHLO cloudshare', 250);
        await cmd('AUTH LOGIN', 334);
        await cmd(b64(CFG.qqUser), 334);
        await cmd(b64(CFG.qqPass), 235);
        await cmd('MAIL FROM:<' + CFG.qqUser + '>', 250);
        await cmd('RCPT TO:<' + to + '>', 250);
        await cmd('DATA', 354);
        sock.write(buildMime(CFG.qqUser, to, subject, text) + '\r\n.\r\n');
        const r = await next();
        if (!r || r.code !== 250) throw new Error('SMTP 投递失败：' + (r ? r.line : '无响应'));
        try { sock.write('QUIT\r\n'); } catch (e) { /* ignore */ }
        done(null);
      } catch (e) {
        done(e);
      }
    });
  });
}

/* ------------------------------------------------------------------ */
/* 2. GitHub 存取账号表（Contents API）                                */
/* ------------------------------------------------------------------ */

function ghRequest(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const headers = {
      'User-Agent': 'CloudShare-Function',
      'Accept': 'application/vnd.github+json',
      'Authorization': 'token ' + CFG.ghToken,
    };
    if (payload) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(payload);
    }
    const req = https.request({
      host: 'api.github.com',
      path: '/repos/' + CFG.ghRepo + '/contents/' + encodeURI(CFG.ghPath) + path,
      method: method,
      timeout: 15000,
      headers: headers,
    }, (res) => {
      let s = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { s += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: s }));
    });
    req.on('timeout', () => req.destroy(new Error('GitHub 请求超时')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function loadDb() {
  const r = await ghRequest('GET', '?ref=' + CFG.ghBranch);
  if (r.status === 404) return { sha: null, db: { accounts: {}, codes: {} } };
  if (r.status !== 200) throw new Error('读取账号表失败 HTTP ' + r.status + '：' + r.body.slice(0, 120));
  const j = JSON.parse(r.body);
  const text = Buffer.from(j.content || '', 'base64').toString('utf8');
  let db;
  try { db = JSON.parse(text); } catch (e) { db = {}; }
  db.accounts = db.accounts || {};
  db.codes = db.codes || {};
  return { sha: j.sha, db: db };
}

async function saveDb(sha, db) {
  const content = Buffer.from(JSON.stringify(db, null, 2), 'utf8').toString('base64');
  const body = { message: 'update accounts ' + new Date().toISOString(), content: content, branch: CFG.ghBranch };
  if (sha) body.sha = sha;
  for (let attempt = 0; attempt < 3; attempt++) {
    const r = await ghRequest('PUT', '', body);
    if (r.status === 200 || r.status === 201) return true;
    if ((r.status === 409 || r.status === 422) && attempt < 2) {
      const fresh = await loadDb();   // sha 变了，重新取一次再写
      body.sha = fresh.sha;
      continue;
    }
    throw new Error('写入账号表失败 HTTP ' + r.status + '：' + r.body.slice(0, 120));
  }
  throw new Error('写入账号表失败：多次冲突');
}

/* ------------------------------------------------------------------ */
/* 3. 工具                                                             */
/* ------------------------------------------------------------------ */

const QQ_RE = /^[1-9]\d{4,11}$/;
const PWD_RE = /^[\x21-\x7e]{8,16}$/;

function hashPassword(pwd, salt) {
  const s = salt || crypto.randomBytes(12).toString('hex');
  const h = crypto.scryptSync(pwd, s, 32).toString('hex');
  return 'scrypt$' + s + '$' + h;
}

function checkPassword(pwd, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 3) return false;
  const calc = hashPassword(pwd, parts[1]);
  const a = Buffer.from(calc);
  const b = Buffer.from(stored);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function fail(message) { return { success: false, message: message }; }

function missConfig() {
  const miss = [];
  if (!CFG.qqUser) miss.push('QQ_USER');
  if (!CFG.qqPass) miss.push('QQ_PASS');
  if (!CFG.ghToken) miss.push('GH_TOKEN');
  if (!CFG.ghRepo) miss.push('GH_REPO');
  return miss;
}

/* ------------------------------------------------------------------ */
/* 4. 业务                                                             */
/* ------------------------------------------------------------------ */

async function handleSendCode(qq) {
  if (!QQ_RE.test(qq)) return fail('QQ 号格式不对（5-12 位数字）');
  const loaded = await loadDb();
  const db = loaded.db;

  const old = db.codes[qq];
  if (old && Date.now() - (old.sentAt || 0) < 60000) {
    const left = Math.ceil((60000 - (Date.now() - old.sentAt)) / 1000);
    return fail('发送太频繁，请 ' + left + ' 秒后再试');
  }

  const code = String(crypto.randomInt(100000, 1000000));
  const mail = qq + '@qq.com';
  await sendMail(
    mail,
    'CloudShare 验证码',
    '你的验证码是：' + code + '\n\n'
      + '10 分钟内有效，请勿告诉他人。\n'
      + '如果不是你本人操作，请忽略这封邮件。\n\n'
      + '—— CloudShare 资源库'
  );

  db.codes[qq] = { code: code, exp: Date.now() + 10 * 60 * 1000, sentAt: Date.now() };
  Object.keys(db.codes).forEach(function (k) {
    if (!db.codes[k] || db.codes[k].exp < Date.now()) delete db.codes[k];
  });
  await saveDb(loaded.sha, db);
  return { success: true, message: '验证码已发送到 ' + mail };
}

async function handleVerifyCode(qq, code, password) {
  if (!QQ_RE.test(qq)) return fail('QQ 号格式不对（5-12 位数字）');
  if (!PWD_RE.test(password || '')) return fail('密码需 8-16 位英文、数字或符号');
  const loaded = await loadDb();
  const db = loaded.db;
  const acc = db.accounts[qq];

  if (acc) {
    // 已注册：校验密码即可登录（验证码可留空）
    if (!checkPassword(password, acc.pwd)) return fail('密码不对，忘记密码请点「忘记密码？」');
    return { success: true, message: '登录成功', isNew: false };
  }

  // 未注册：验证码必须正确
  const c = db.codes[qq];
  if (!c) return fail('请先点「获取验证码」');
  if (c.exp < Date.now()) return fail('验证码已过期，请重新获取');
  if (String(code || '').trim() !== c.code) return fail('验证码不对');

  db.accounts[qq] = {
    pwd: hashPassword(password),
    mail: qq + '@qq.com',
    createdAt: new Date().toISOString(),
  };
  delete db.codes[qq];
  await saveDb(loaded.sha, db);
  return { success: true, message: '注册成功，已自动登录', isNew: true };
}

async function handleResetPassword(qq, code, password) {
  if (!QQ_RE.test(qq)) return fail('QQ 号格式不对（5-12 位数字）');
  if (!PWD_RE.test(password || '')) return fail('密码需 8-16 位英文、数字或符号');
  const loaded = await loadDb();
  const db = loaded.db;
  if (!db.accounts[qq]) return fail('该 QQ 号还没有注册');

  const c = db.codes[qq];
  if (!c) return fail('请先点「获取验证码」');
  if (c.exp < Date.now()) return fail('验证码已过期，请重新获取');
  if (String(code || '').trim() !== c.code) return fail('验证码不对');

  db.accounts[qq].pwd = hashPassword(password);
  db.accounts[qq].updatedAt = new Date().toISOString();
  delete db.codes[qq];
  await saveDb(loaded.sha, db);
  return { success: true, message: '密码已重置，请用新密码登录' };
}

/* ------------------------------------------------------------------ */
/* 5. 入口                                                             */
/* ------------------------------------------------------------------ */

exports.main = async function (event) {
  const miss = missConfig();
  if (miss.length) {
    return { success: false, message: '云函数未配置环境变量：' + miss.join('、') };
  }

  let raw = '';
  try {
    if (event && typeof event.body === 'string') {
      raw = event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body;
    } else if (event && event.body) {
      raw = JSON.stringify(event.body);
    } else {
      raw = JSON.stringify(event || {});
    }
  } catch (e) {
    return { success: false, message: '请求体解析失败' };
  }

  let body;
  try {
    body = JSON.parse(raw || '{}');
  } catch (e) {
    return { success: false, message: '请求体不是合法 JSON：' + raw.slice(0, 60) };
  }

  const action = body.action;
  const qq = String(body.qqNumber || '').trim();
  const code = String(body.code || '').trim();
  const password = String(body.password || '');

  try {
    if (action === 'sendCode') return await handleSendCode(qq);
    if (action === 'verifyCode') return await handleVerifyCode(qq, code, password);
    if (action === 'resetPassword') return await handleResetPassword(qq, code, password);
    return { success: false, message: '未知 action：' + action };
  } catch (e) {
    // 真实原因直接带回 App 显示，方便排查
    return { success: false, message: '云函数出错：' + (e && e.message ? e.message : String(e)) };
  }
};